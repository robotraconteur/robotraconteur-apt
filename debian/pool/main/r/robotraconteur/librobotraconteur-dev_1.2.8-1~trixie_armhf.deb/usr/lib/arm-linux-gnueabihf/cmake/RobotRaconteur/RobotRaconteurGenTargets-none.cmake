#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RobotRaconteurGen" for configuration "None"
set_property(TARGET RobotRaconteurGen APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(RobotRaconteurGen PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/bin/RobotRaconteurGen"
  )

list(APPEND _cmake_import_check_targets RobotRaconteurGen )
list(APPEND _cmake_import_check_files_for_RobotRaconteurGen "${_IMPORT_PREFIX}/bin/RobotRaconteurGen" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
