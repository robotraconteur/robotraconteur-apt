#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RobotRaconteurCore" for configuration "None"
set_property(TARGET RobotRaconteurCore APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(RobotRaconteurCore PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libRobotRaconteurCore.so.1.2.8"
  IMPORTED_SONAME_NONE "libRobotRaconteurCore.so.1"
  )

list(APPEND _cmake_import_check_targets RobotRaconteurCore )
list(APPEND _cmake_import_check_files_for_RobotRaconteurCore "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libRobotRaconteurCore.so.1.2.8" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
