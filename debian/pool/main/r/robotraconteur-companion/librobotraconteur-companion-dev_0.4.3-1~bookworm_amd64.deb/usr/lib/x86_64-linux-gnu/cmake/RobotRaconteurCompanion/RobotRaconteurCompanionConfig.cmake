
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was Config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../" ABSOLUTE)

# Use original install prefix when loaded through a "/usr move"
# cross-prefix symbolic link such as /lib -> /usr/lib.
get_filename_component(_realCurr "${CMAKE_CURRENT_LIST_DIR}" REALPATH)
get_filename_component(_realOrig "/usr/lib/x86_64-linux-gnu/cmake/RobotRaconteurCompanion" REALPATH)
if(_realCurr STREQUAL _realOrig)
  set(PACKAGE_PREFIX_DIR "/usr")
endif()
unset(_realOrig)
unset(_realCurr)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include("${CMAKE_CURRENT_LIST_DIR}/RobotRaconteurCompanionTargets.cmake")

set(RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR ${PACKAGE_PREFIX_DIR}/share/robotraconteur/robdef/standard_robdef/)

set(RobotRaconteur_STANDARD_ROBDEF_SERVICE_NAMES com.robotraconteur.action;com.robotraconteur.actuator;com.robotraconteur.bignum;com.robotraconteur.color;com.robotraconteur.datatype;com.robotraconteur.datetime.clock;com.robotraconteur.datetime;com.robotraconteur.device.clock;com.robotraconteur.device.isoch;com.robotraconteur.device;com.robotraconteur.eventlog;com.robotraconteur.fiducial;com.robotraconteur.geometry;com.robotraconteur.geometry.shapes;com.robotraconteur.geometryf;com.robotraconteur.geometryi;com.robotraconteur.gps;com.robotraconteur.hid.joystick;com.robotraconteur.identifier;com.robotraconteur.image;com.robotraconteur.imaging.camerainfo;com.robotraconteur.imaging;com.robotraconteur.imu;com.robotraconteur.laserscan;com.robotraconteur.laserscanner;com.robotraconteur.lighting;com.robotraconteur.objectrecognition;com.robotraconteur.octree;com.robotraconteur.param;com.robotraconteur.pid;com.robotraconteur.pointcloud;com.robotraconteur.pointcloud.sensor;com.robotraconteur.resource;com.robotraconteur.resource.device;com.robotraconteur.robotics.joints;com.robotraconteur.robotics.payload;com.robotraconteur.robotics.robot;com.robotraconteur.robotics.tool;com.robotraconteur.robotics.trajectory;com.robotraconteur.sensor;com.robotraconteur.sensordata;com.robotraconteur.servo;com.robotraconteur.signal;com.robotraconteur.units;com.robotraconteur.uuid)
set(RobotRaconteur_STANDARD_ROBDEF_FILES ${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.action.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.actuator.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.bignum.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.color.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.datatype.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.datetime.clock.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.datetime.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.device.clock.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.device.isoch.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.device.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.eventlog.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.fiducial.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.geometry.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.geometry.shapes.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.geometryf.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.geometryi.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.gps.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.hid.joystick.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.identifier.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.image.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.imaging.camerainfo.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.imaging.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.imu.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.laserscan.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.laserscanner.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.lighting.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.objectrecognition.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.octree.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.param.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.pid.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.pointcloud.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.pointcloud.sensor.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.resource.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.resource.device.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.robotics.joints.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.robotics.payload.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.robotics.robot.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.robotics.tool.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.robotics.trajectory.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.sensor.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.sensordata.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.servo.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.signal.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.units.robdef;${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1/com.robotraconteur.uuid.robdef)
set(RobotRaconteur_STANDARD_ROBDEF_DIRS ${RobotRaconteur_STANDARD_ROBDEF_ROOT_DIR}/group1)

find_package(yaml-cpp REQUIRED)
find_package(Eigen3 3.3 NO_MODULE QUIET)
if(NOT Eigen3_FOUND)
    find_package(Eigen3 3.3...<6 REQUIRED NO_MODULE)
endif()
