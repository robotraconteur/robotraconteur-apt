#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RobotRaconteurCompanion" for configuration "None"
set_property(TARGET RobotRaconteurCompanion APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(RobotRaconteurCompanion PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libRobotRaconteurCompanion.so.0.4.3"
  IMPORTED_SONAME_NONE "libRobotRaconteurCompanion.so.0.4"
  )

list(APPEND _IMPORT_CHECK_TARGETS RobotRaconteurCompanion )
list(APPEND _IMPORT_CHECK_FILES_FOR_RobotRaconteurCompanion "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libRobotRaconteurCompanion.so.0.4.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
