#include "yaml_parser_common_include.h"

#pragma once

namespace YAML
{

}
